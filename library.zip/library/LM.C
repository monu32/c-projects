#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<string.h>


		  //<< PROGRAM OF LIBRARY MANAGEMENT >>


void register_book();
void search_book();
void display_book();
void delete_book();
void issue_book();
void return_book();
void update_issue(int);
void update_return(int);
void show_issue();

  struct id
  {
   char name[20];
   int enrollment;
   char branch[20];
  };

  struct book
   {
    char book_name[20];
    int book_id;
    char book_writer[20];
   };



int k=0;

 void register_user()
  {
   struct id u;
   FILE *fp;
   fp=fopen("user","ab");
   printf("\n Enter your name= ");
   fflush(stdin);
   gets(u.name);
   fflush(stdin);
   printf("\n Enter your Enrollment number= ");
   scanf("%d",&u.enrollment);
   fflush(stdin);
   printf("\n Enter your branch= ");
   gets(u.branch);
   fwrite(&u,sizeof(u),1,fp);
   delay(500);
   printf("\n<< Acount created Sucessfully >> ");
   fclose(fp);
  }

 void user_login()
  {
   FILE *fp;
   struct id u;
   int enroll;
   int found;
   fp=fopen("user","rb");
   printf("\n Enter your enrollment number (positive integer)= ");
   scanf("%d",&enroll);
   while(fread(&u,sizeof(u),1,fp));
    {
     if(enroll==u.enrollment)
      {
       found=1;
       k=1;
      }
    else
     printf("\n Sorry your account doesn't exist...!!!");
    }

    if(found==1)
      {
       int choice;

    do
      {
      if(found!=1)
       getch();
     else
      found=0;
       clrscr();
       delay(700);
       printf("\n\n\n Functions for operation perform :-");
       printf("\n\n\n 1)Register new book");
       printf("\n 2)Search book");
       printf("\n 3)Display all books");
       printf("\n 4)Delete book");
       printf("\n 5)Issue book");
       printf("\n 6)Return book");
       printf("\n 7)Show issue books");
       printf("\n 8)Enter 8 for previous page ");
       printf("\n\n Enter your choice (1-8) = ");
       scanf("%d",&choice);


	switch(choice)
	 {
	  case 1: register_book();
	  break;

	  case 2: search_book();
	  break;

	  case 3: display_book();
	  break;

	  case 4: delete_book();
	  break;

	  case 5: issue_book();
	  break;

	  case 6: return_book();
	  break;

	  case 7: show_issue();

	  case 8: break;

	  case 9: default:
	  printf("\n\n  Please Enter right choice from list...");
	  printf("\n  Press Enter to continue...");

	 }
      }while(choice!=8);
    }
  fclose(fp);
 }

 void register_book()
 {
  FILE *fp,*fp2;
  struct book b;
  fp=fopen("book","ab");
  fp2=fopen("temp","ab");
  fflush(stdin);
  printf("\n Enter book name= ");
  gets(b.book_name);
  fflush(stdin);
  printf("\n Enter book id= ");
  scanf("%d",&b.book_id);
  fflush(stdin);
  printf("\n Enter book writer= ");
  gets(b.book_writer);
  fwrite(&b,sizeof(b),1,fp);
  fwrite(&b,sizeof(b),1,fp2);
  printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
  fclose(fp);
  fclose(fp2);
 }

void search_book()
 {
  FILE *fp;
  struct book b;
  char name[20];
  int id;
  int found;
  fp=fopen("book","rb");
  fflush(stdin);
  printf("\n Enter book name= ");
  gets(name);
  printf("\n Enter book_id= ");
  scanf("%d",&id);
  while(fread(&b,sizeof(b),1,fp))
   {
    if((strcmp((b.book_name),name)==0)&&(id==b.book_id))
    {
     found=1;
     break;
    }
   }

 if(found==1)
  {
   printf("\n Book is Found...\n");
   printf("\n\n Book name = %s ",b.book_name);
   printf(" Book id     = %d ",b.book_id);
   printf(" Book writer = %s",b.book_writer);
  }
 else
  printf("\n Book is Not Found...!!! \n");
 printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
 fclose(fp);
}

void display_book()
 {
  FILE *fp;
  struct book b;
  int flag=0;
  fp=fopen("book","rb");
  while(fread(&b,sizeof(b),1,fp))
   {
    flag=1;
    printf("\n\n Book name  = %s",b.book_name);
    printf("\n Book id    = %d",b.book_id);
    printf("\n Book author= %s",b.book_writer);
   }
   if(flag==0)
    printf("\n Please insert book to display");
  printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
 fclose(fp);
}


 void delete_book()
  {
   FILE *fp1,*fp2,*fp3,*fp4;
   struct book b;
   int id,flag=0;
   fp1=fopen("book","rb");
   fp2=fopen("book1","ab");
   fp3=fopen("temp","rb");
   fp4=fopen("temp1","ab");
   printf("\n Enter book id number to delet book= ");
   scanf("%d",&id);
   while(fread(&b,sizeof(b),1,fp1))
    {
     if(id!=b.book_id)
       fwrite(&b,sizeof(b),1,fp2);
     else
     {
      printf("\n << Book deleted sucessfully from library... >>");
      flag=1;
     }
    }
   while(fread(&b,sizeof(b),1,fp3))
    {
     if(id!=b.book_id)
      fwrite(&b,sizeof(b),1,fp4);
    }
  if(flag==0)
   printf("\n Sorry book not found...!!!");
 printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
  fclose(fp1);
  fclose(fp2);
  fclose(fp3);
  fclose(fp4);
  remove("book");
  rename("book1","book");

  remove("temp");
  rename("temp1","temp");

}

void issue_book()
 {
  FILE *fp1,*fp2;
  char name[20];
  struct book b;
  int id,found=0;
  fp1=fopen("issue","ab");
  fp2=fopen("temp","rb");
  fflush(stdin);
  printf("\n Enter name of a book= ");
  gets(name);
  fflush(stdin);
  printf("\n Enter ID of a book= ");
  scanf("%d",&id);
  while(fread(&b,sizeof(b),1,fp2))
  {
   if((strcmp(name,b.book_name)==0)&&(id==b.book_id))
    {
     fwrite(&b,sizeof(b),1,fp1);
     update_issue(id);
     found=1;
     break;
    }
  }

    if((found==1)&&(b.book_id==id))
     {
      printf("\n Fine will be charge if the date could exceded");
      printf("\n << Your Book is issue... >>");
     }
   else
    {
    printf("\n Book is not present in a library or alreadu issued...!!");
    }

  printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
 fclose(fp1);
 fclose(fp2);
}

void update_issue(int id)
 {
  FILE *fp1,*fp2;
  struct book b;
  fp1=fopen("temp","rb");
  fp2=fopen("temp2","ab");
   while(fread(&b,sizeof(b),1,fp1))
    {
     if(id!=b.book_id)
      fwrite(&b,sizeof(b),1,fp2);
    }
  fclose(fp1);
  fclose(fp2);
  remove("temp");
  rename("temp2","temp");
 }

void show_issue()
 {
  FILE *fp;
  int flag=0;
  struct book b;
  fp=fopen("issue","rb");
  while(fread(&b,sizeof(b),1,fp))
   {
    flag=1;
    printf("\n\n Book name=%s",b.book_name);
    printf("\n Book ID=%d",b.book_id);
   }
   if(flag==0)
    printf("\n No book is issued....");
   printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
 fclose(fp);
 }



void return_book()
 {
  FILE *fp1,*fp2;
  int id;
  struct book b;
  int found=0;
  char name[20];
  fp1=fopen("issue","rb");
  fp2=fopen("temp","ab");
  fflush(stdin);
  printf("\n Please enter name of a book return= ");
  gets(name);
  fflush(stdin);
  printf("\n Please enter ID of a book to return= ");
  scanf("%d",&id);
  while(fread(&b,sizeof(b),1,fp1))
   {
    if((strcmp(name,b.book_name)==0)&&(id==b.book_id))
     {
      found=1;
      fwrite(&b,sizeof(b),1,fp2);
      update_return(id);
      break;
     }
  }

 if(found==1)
  printf("\n<< Book is sucessfully return... >>");
 else
  printf("\n No book issue of this subject...!!!");

fclose(fp1);
fclose(fp2);
 printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");

}

void update_return(int id)
 {
   FILE *fp1,*fp2;
   struct book b;
   fp1=fopen("issue","rb");
   fp2=fopen("issue1","ab");
   while(fread(&b,sizeof(b),1,fp1))
    {
     if(id!=b.book_id)
       fwrite(&b,sizeof(b),1,fp2);
    }
  fclose(fp1);
  fclose(fp2);
  remove("issue");
  rename("issue1","issue");
 }

void main()
 {
  int choice=0;
  clrscr();
 while(1)
 {
 if((choice!=0)&&(k==0))
  getch();
  clrscr();
  gotoxy(19,6);
  printf("\" PROJECT ON LIBRARY MANAGEMENT \"");
  printf("\n\n\n  1) Register user");
  printf("\n  2) User login");
  printf("\n  3) EXIT");
  printf("\n Enter your choice (1-3)= ");
  fflush(stdin);
  scanf("%d",&choice);

  switch(choice)
   {
    case 1: register_user();
    break;

    case 2: user_login();
    break;

    case 3: exit();

    case 4: default:
    printf("\n Please enter right choice...!!!");
    printf("\n\n\n \" PRESS Enter to choose another option in Menu \"");
   }
 }
}
